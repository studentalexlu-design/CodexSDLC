# guidelines/ — 你們團隊的開發規範

這個目錄是**你的**：升級不會覆蓋這裡的規範。裝好時附的 `api.md`、`sql.md`、`coding.md`、`testing.md`、`rules.json` 都是範例，請換成你們自己的；不需要規範就整個刪掉，流程照常跑。

**怎麼寫、誰會讀、`rules.json` 的格式、怎麼從審核歸納規範** → [`.codex/bdd-workflow/guidelines-guide.md`](../.codex/bdd-workflow/guidelines-guide.md)。那份說明屬於工作流，每次 `update` 會跟著換成新版。

這份 README 你沒改過的話，`update` 會換成新版；改過（例如寫成你們團隊自己的說明）就不會動。
