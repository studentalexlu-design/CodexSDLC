# build-check.ps1
# 只在 production 程式碼變更時執行 build。
# 讀 hook payload（stdin），抽出檔案路徑；僅原始碼／專案檔觸發，
# 且排除 bdd-docs/**、*.md 與測試檔（測試專案、src/test/、*Steps）。無命中即靜默 exit 0。
#
# build 的是整個 solution（`commands.build`），不是改到的那個專案：16 個專案的 solution 實測，單一專案的增量 build
# 只快約 0.7 秒（4.3 vs 5.0 秒；連什麼都沒改都要 4.8 秒，幾乎全是 dotnet 每次呼叫的固定開銷），
# 而直接 build 單一 csproj 時 $(SolutionDir) 是空的、solution 的組態對應也不套用 —— 舊專案在那裡誤擋的代價大得多。
# 省時間的是「不叫」：測試檔不觸發、綠燈去抖。
#
# 語言與 build 命令取自 repo-index 的 `commands`；索引不存在時退化為副檔名偵測。
# 支援 .NET（dotnet）與 Java（maven／gradle）；Node／TypeScript 跑型別檢查（每個 package.json 一個單位，見下面的 Node 段落）。
#
# **綠燈時去抖（debounce）。** 本 hook 掛在每一次 apply_patch 上，而一次邏輯變更
# 通常由數個 patch 組成 —— 每個 patch 都 build 一次是純等待，且 implementer
# 本來就會在每個 micro-iteration 跑測試（也會 build）。因此：
#   build 成功 → 寫時間戳，之後 $DebounceSeconds 內的變更略過 build
#   build 失敗 → 刪除時間戳，之後每一次變更都重跑，直到恢復綠燈
# 去抖只作用在「已經綠燈」的情況，紅燈時的回饋速度完全不受影響。
#
# Exit: 0 = 無需 build 或 build 成功；2 = build 或型別檢查失敗（阻斷）。

[CmdletBinding()]
param(
    [string]$Payload,
    [string]$IndexPath = 'bdd-docs/.cache/index.json',
    [int]$DebounceSeconds = 90,   # 0 = 停用去抖（每次都 build）
    [switch]$WhatIfPaths   # 只印出判定結果，不實際 build（測試用）
)

# ---- hook payload → 這次寫出去的檔 ----
# 三支 PostToolUse gate（dlp-gate／guideline-gate／build-check）各有一份**逐字相同**的副本：
# gate 必須能獨立跑，少複製一支共用檔不該讓三支一起靜默失效。重複由 test-hook-payload.ps1 守住
# （三支的 Read-HookPayload 必須逐字相同）。
#
# 形狀以 Codex 0.154.0 實測為準：
#   apply_patch → tool_input.command 是整份 patch；路徑在 `*** Add File:`／`*** Update File:`／`*** Move to:`，**沒有引號**
#   Bash        → tool_input.command 是 shell 指令；路徑通常帶引號
# 舊版只認引號包住的路徑 —— apply_patch 寫的檔一個都抽不到，而那正是 agent 寫檔的主要途徑。症狀是零。
#
# 只看 tool_input（有的話）：其餘欄位裡的 transcript_path 是一個 .jsonl，那是對話紀錄，不是這次寫的檔。
# patch 內文裡的引號字串是**檔案內容**，不算路徑。
function Read-HookPayload([string]$raw) {
    $result = [pscustomobject]@{ event = ''; paths = @() }
    if (-not $raw) { return $result }
    $texts = @(); $tool = ''
    try {
        $doc = $raw | ConvertFrom-Json -ErrorAction Stop
        if ($doc -is [pscustomobject] -and $doc.PSObject.Properties['hook_event_name']) { $result.event = [string]$doc.hook_event_name }
        if ($doc -is [pscustomobject] -and $doc.PSObject.Properties['tool_name']) { $tool = [string]$doc.tool_name }
        $scope = if ($doc -is [pscustomobject] -and $doc.PSObject.Properties['tool_input']) { $doc.tool_input } else { $doc }
        $queue = [System.Collections.Generic.Queue[object]]::new()
        $queue.Enqueue($scope)
        while ($queue.Count -gt 0) {
            $cur = $queue.Dequeue()
            if ($null -eq $cur) { continue }
            if ($cur -is [string]) { $texts += $cur; continue }
            if ($cur -is [ValueType]) { continue }
            if ($cur -is [System.Collections.IEnumerable]) { foreach ($i in $cur) { $queue.Enqueue($i) }; continue }
            foreach ($p in $cur.PSObject.Properties) { $queue.Enqueue($p.Value) }
        }
    } catch { $texts = @($raw) }

    $paths = @(); $mentioned = @()
    foreach ($t in $texts) {
        if ($t -match '(?m)^\*\*\* Begin Patch') {
            foreach ($m in [regex]::Matches($t, '(?m)^\*\*\* (?:Add File|Update File|Move to):[ \t]*(.+?)[ \t]*\r?$')) { $paths += $m.Groups[1].Value }
            continue
        }
        foreach ($m in [regex]::Matches($t, '["'']([^"''\r\n]*?\.[A-Za-z0-9]{1,10})["'']')) { $mentioned += $m.Groups[1].Value }
        foreach ($m in [regex]::Matches($t, '["''](bdd-docs[\\/][^"''\r\n]*)["'']')) { $mentioned += $m.Groups[1].Value }
        foreach ($m in [regex]::Matches($t, '(?<![\w.\\/-])(bdd-docs[\\/][^\s"''`;|&<>(){}]+)')) { $mentioned += $m.Groups[1].Value }
        if ($t -match '^[^"''\r\n*]+\.[A-Za-z0-9]{1,10}$') { $mentioned += $t }
    }
    # shell 指令裡的路徑只是「被提到」：`Get-Content -Path 'legacy/report.sql'`、`rg -n "Status" "x.sql"` 都抽得到，
    # 而那些檔這次沒被寫。不篩的話，讀一個不合新規範的舊檔就收到一句「現在就改掉」—— 唯讀的 agent 被叫去改舊檔。
    # 所以只留這次真的被寫到的：修改或建立時間在 120 秒內（建立時間接得住保留修改時間的 Copy-Item）。
    # 不用 git status：這套流程從不 commit，bdd-docs/ 與上一個需求改過的檔永遠是「已修改／未追蹤」，等於沒篩。
    # patch 標頭本來就是寫的檔，不篩；其他工具（Edit／Write 的 file_path）也是寫，不篩。
    if ($tool -match '^(Bash|shell)$') {
        $now = [DateTime]::UtcNow
        $mentioned = @($mentioned | Where-Object {
            $f = $_.Trim()
            try {
                if (-not [IO.Path]::IsPathRooted($f)) { $f = Join-Path (Get-Location).Path $f }
                if (-not [IO.File]::Exists($f)) { return $false }
                $touched = [IO.File]::GetLastWriteTimeUtc($f)
                $created = [IO.File]::GetCreationTimeUtc($f)
                if ($created -gt $touched) { $touched = $created }
                return (($now - $touched).TotalSeconds -le 120)
            } catch { return $false }
        })
    }
    $result.paths = @(($paths + $mentioned) | Where-Object { $_ } | ForEach-Object { $_.Trim() } | Sort-Object -Unique)
    return $result
}

# ---- 標準 I/O：被程式呼叫時一律 UTF-8 ----
# Codex 送進來的 payload 是 UTF-8、也用 UTF-8 解讀 hook 的輸出；Windows 上 [Console] 的編碼卻跟著 console 的
# code page 走（zh-TW 是 cp950；並行的 hook 共用同一個 console，偶爾連輸出端也是）。Codex 0.154.0 實測的後果：
# 一份 743 字、meta 完整的中文 handoff 被解成 1772 字、JSON 解析失敗、抓不到 mode —— **每一次 spawn 都被擋**；
# 阻斷理由的中文到模型手上是亂碼。只在被重導向時才換：人在終端機跑的時候照 console 的 code page 顯示。
# 同一段在每一支會被程式呼叫的腳本裡各有一份（清單由 test-hook-payload.ps1 守住）。
$Utf8NoBom = [Text.UTF8Encoding]::new($false)
if ([Console]::IsOutputRedirected) { $w = [IO.StreamWriter]::new([Console]::OpenStandardOutput(), $Utf8NoBom); $w.AutoFlush = $true; [Console]::SetOut($w) }
if ([Console]::IsErrorRedirected)  { $w = [IO.StreamWriter]::new([Console]::OpenStandardError(),  $Utf8NoBom); $w.AutoFlush = $true; [Console]::SetError($w) }
function Read-StdinUtf8 {
    if ([Console]::IsInputRedirected) { return [IO.StreamReader]::new([Console]::OpenStandardInput(), $Utf8NoBom).ReadToEnd() }
    return [Console]::In.ReadToEnd()
}

# ---- 心跳：證明 hook 真的有在跑 ----
# 四支 hook（handoff-lint／dlp-gate／guideline-gate／build-check）各有一份**逐字相同**的副本（test-hook-payload.ps1 守住）。
# Codex 沒信任 hooks、hooks.json 改過待重審、或叫不起 pwsh 時，這四支一次都不會跑，而且沒有任何提示 ——
# 看得見那件事的唯一線索是「agent 寫了產出，這裡的檔卻沒跟著變新」。doctor 拿它跟 bdd-docs/ 的產出比（Get-HookHeartbeat）。
# 只在 hook 在叫（payload 帶 hook_event_name）時寫：手動跑、-Path、-Json 都不算數。
# 寫不進去就算了 —— 心跳是證據，不是 gate；為了它讓一次寫檔或委派失敗是本末倒置。
function Write-HookHeartbeat([string]$eventName, [string]$name) {
    if (-not $eventName) { return }
    try {
        $dir = Join-Path (Get-Location).Path 'bdd-docs/.cache/hooks'
        [void][IO.Directory]::CreateDirectory($dir)
        [IO.File]::WriteAllText((Join-Path $dir "$name.last"), "$([DateTime]::UtcNow.ToString('o')) $eventName`n", [Text.UTF8Encoding]::new($false))
    } catch { }
}

if (-not $Payload) { $Payload = Read-StdinUtf8 }
if (-not $Payload) { exit 0 }

$hook = Read-HookPayload $Payload
Write-HookHeartbeat $hook.event 'build-check'
$paths = $hook.paths

# 語言／建置命令：優先取自索引，退化為副檔名偵測
$buildCmd = $null
$extRe    = '\.(cs|csproj|sln|java)$'
if (Test-Path $IndexPath) {
    try {
        $idx = Get-Content $IndexPath -Raw | ConvertFrom-Json
        # 只有前端的專案，索引的 commands 是前端的（型別檢查）—— 那一份由下面的 Node 段落自己從 package.json 推，這裡不拿。
        if ($idx.commands.build -and $idx.meta.'build-tool' -in 'dotnet', 'maven', 'gradle') { $buildCmd = $idx.commands.build }
        switch ($idx.meta.language) {
            'java'   { $extRe = '\.(java|gradle|kts)$|(^|/)pom\.xml$' }
            'csharp' { $extRe = '\.(cs|csproj|sln)$' }
        }
    } catch { }
}

# ---- 測試檔不觸發 ----
# test-first 先寫測試，這時 production code 還沒寫，本來就編不過。紅燈期間刻意不去抖，於是每個 patch 都重 build 一次
# 整個 solution，再回一句「Build FAILED after production code change」擋下 —— 改的其實是測試檔。
# 測試的編譯錯誤 implementer 跑測試時就看得到（④ 的測試指令會先 build），這支 hook 只管 production code。
# 判定：Java 的 src/test/ 一類目錄、*Steps.cs／*Steps.java（step definitions），以及屬於測試專案的 .cs／.csproj ——
# 往上找到的第一個 .csproj 檔名以 Test／Tests 結尾、宣告 IsTestProject、用 MSTest.Sdk，或引用了測試框架的套件。
$script:CsprojIsTest = @{}
function Test-IsTestCsproj([string]$csproj) {
    if (-not $script:CsprojIsTest.ContainsKey($csproj)) {
        $isTest = [IO.Path]::GetFileName($csproj) -match '(?i)tests?\.csproj$'
        if (-not $isTest) {
            $x = ''
            try { $x = [IO.File]::ReadAllText($csproj) } catch { }
            $isTest = $x -match '(?i)<IsTestProject>\s*true\s*</IsTestProject>|Sdk="MSTest\.Sdk|<PackageReference\s+Include="(Microsoft\.NET\.Test\.Sdk|xunit(\.v3)?|NUnit|MSTest(\.TestFramework)?|Reqnroll[\w.]*|SpecFlow[\w.]*)"'
        }
        $script:CsprojIsTest[$csproj] = $isTest
    }
    return $script:CsprojIsTest[$csproj]
}
function Test-IsTestPath([string]$p) {
    $rel = $p -replace '\\', '/'
    if ($rel -match '(?i)(^|/)src/(test|it|integration-?test|testFixtures)/') { return $true }
    if ($rel -match '(?i)(Steps|StepDefinitions?)\.(cs|java)$') { return $true }
    if ($rel -notmatch '(?i)\.(cs|csproj)$') { return $false }
    $root = (Get-Location).Path
    $full = if ([IO.Path]::IsPathRooted($p)) { $p } else { Join-Path $root $p }
    if ($rel -match '(?i)\.csproj$') { return (Test-IsTestCsproj $full) }
    $dir = Split-Path $full -Parent
    while ($dir -and $dir.StartsWith($root, [StringComparison]::OrdinalIgnoreCase)) {
        $proj = @(Get-ChildItem -LiteralPath $dir -Filter *.csproj -File -ErrorAction SilentlyContinue) | Select-Object -First 1
        if ($proj) { return (Test-IsTestCsproj $proj.FullName) }
        $parent = Split-Path $dir -Parent
        if ($parent -eq $dir) { break }
        $dir = $parent
    }
    return $false
}

$candidates = @($paths | Where-Object {
    $p = $_ -replace '\\', '/'
    ($p -match $extRe) -and ($p -notmatch '(^|/)bdd-docs/')
})
$testOnly   = @($candidates | Where-Object { Test-IsTestPath $_ })
$triggering = @($candidates | Where-Object { $_ -notin $testOnly })

# ---- Node／TypeScript：型別檢查，每個套件（package.json）各跑各的 ----
# 指令從 package.json 直接推（lib/node-project.ps1，跟 repo-index 同一份判定），不讀索引：讀一個 package.json 比讀索引還便宜，
# 也不會因為索引舊了而跑錯指令。.js 不觸發 —— 它沒有「編譯」這一步，lint 不是這支 hook 的事。
# 共用檔不在（只複製了這一支）就跳過這一段，後端那段照常 —— 少一個檔不該讓整支 hook 失效。
$nodeUnits = [ordered]@{}   # 套件目錄 → 觸發的檔
$nodeTestOnly = @()
$nodeLib = Join-Path $PSScriptRoot 'lib/node-project.ps1'
if (Test-Path -LiteralPath $nodeLib) {
    . $nodeLib
    $root = (Get-Location).Path
    foreach ($p in $paths) {
        $rel = $p -replace '\\', '/'
        if ($rel -match '(^|/)(bdd-docs|node_modules)/' -or $rel -notmatch "$($script:NodeTypedRe)|(^|/)tsconfig[^/]*\.json$") { continue }
        if ($rel -match $script:NodeIgnoredRe) { continue }
        if (Test-NodeTestPath $rel) { $nodeTestOnly += $p; continue }
        $full = if ([IO.Path]::IsPathRooted($p)) { $p } else { Join-Path $root $p }
        $dir = Find-NodePackageDir $full $root
        if (-not $dir) { continue }
        if (-not $nodeUnits.Contains($dir)) { $nodeUnits[$dir] = @() }
        $nodeUnits[$dir] += $p
    }
}

if ($WhatIfPaths) {
    $nodeCount = @($nodeUnits.Values | ForEach-Object { $_ }).Count
    "detected=$($paths.Count) triggering=$($triggering.Count + $nodeCount) test-skipped=$($testOnly.Count + $nodeTestOnly.Count) build='$buildCmd' extRe='$extRe'"
    $triggering | ForEach-Object { "  TRIGGER $_" }
    foreach ($d in $nodeUnits.Keys) {
        $info = Get-NodeProjectInfo $d (Get-Location).Path
        foreach ($p in $nodeUnits[$d]) { "  TRIGGER $p" }
        "  NODE $(([IO.Path]::GetRelativePath((Get-Location).Path, $d)) -replace '\\', '/') build='$($info.commands.build)'"
    }
    @($testOnly) + @($nodeTestOnly) | ForEach-Object { "  SKIP-TEST $_" }
    exit 0
}

if (-not $triggering -and -not $nodeUnits.Count) { exit 0 }

# --- 綠燈去抖 ---
# 時間戳依工作目錄雜湊命名，避免多個 repo 互相干擾；前端每個套件各一個（後綴是套件目錄的雜湊）。
$stampDir = [IO.Path]::GetTempPath()
$cwdHash  = [BitConverter]::ToString(
    [Security.Cryptography.MD5]::HashData([Text.Encoding]::UTF8.GetBytes((Get-Location).Path))
).Replace('-', '').Substring(0, 12)
$stamp = Join-Path $stampDir "codex-build-check-$cwdHash.stamp"
function Test-StampFresh([string]$s) {
    if ($DebounceSeconds -le 0 -or -not (Test-Path $s)) { return $false }
    return (((Get-Date) - (Get-Item $s).LastWriteTime).TotalSeconds -lt $DebounceSeconds)
}

# 型別檢查的錯誤在最前面，套件管理器的「script 失敗」在最後 —— 只留最後 10 行，看到的會全是 npm 的雜訊。
function Select-ErrorLines($lines) {
    $all = @($lines | ForEach-Object { "$_" })
    $err = @($all | Where-Object { $_ -match '(?i)\berror\b' -and $_ -notmatch '^\s*(npm (error|ERR!)|ELIFECYCLE|error Command failed|\s*ERR_PNPM)' })
    if ($err.Count) { return @($err | Select-Object -First 10) }
    return @($all | Select-Object -Last 10)
}

$nodeFailed = $false
foreach ($d in $nodeUnits.Keys) {
    $info = Get-NodeProjectInfo $d (Get-Location).Path
    $cmd = $info.commands.build
    if (-not $cmd) { continue }                                         # 沒有可信的型別檢查（純 JS、solution-style tsconfig）
    if (-not (Test-NodeInstalled $d (Get-Location).Path)) { continue }  # 依賴沒裝：工具鏈不可用，不阻斷
    $hash = [BitConverter]::ToString([Security.Cryptography.MD5]::HashData([Text.Encoding]::UTF8.GetBytes($d))).Replace('-', '').Substring(0, 8)
    $nstamp = Join-Path $stampDir "codex-build-check-$cwdHash-$hash.stamp"
    if (Test-StampFresh $nstamp) { continue }
    $segments = @($cmd -split '\s*&&\s*')
    if (-not (Get-Command (($segments[0] -split '\s+')[0]) -ErrorAction SilentlyContinue)) { continue }   # 工具鏈不可用時不阻斷
    $out = @(); $code = 0
    Push-Location -LiteralPath $d
    try {
        foreach ($seg in $segments) {
            $parts = $seg -split '\s+'
            $out += @(& $parts[0] @($parts[1..($parts.Count - 1)]) 2>&1)
            $code = $LASTEXITCODE
            if ($code -ne 0) { break }
        }
    } finally { Pop-Location }
    if ($code -ne 0) {
        Remove-Item $nstamp -ErrorAction SilentlyContinue
        $relDir = ([IO.Path]::GetRelativePath((Get-Location).Path, $d)) -replace '\\', '/'
        [Console]::Error.WriteLine("[Hook] Type check FAILED after production code change ($cmd, in $relDir). Fix before proceeding.")
        Select-ErrorLines $out | ForEach-Object { [Console]::Error.WriteLine($_) }
        $nodeFailed = $true
    } elseif ($DebounceSeconds -gt 0) {
        Set-Content -Path $nstamp -Value (Get-Date -Format o) -NoNewline
    }
}

if (-not $triggering) { exit $(if ($nodeFailed) { 2 } else { 0 }) }
if (Test-StampFresh $stamp) { exit $(if ($nodeFailed) { 2 } else { 0 }) }   # 上次 build 綠燈且仍在視窗內

# 索引沒給命令時，依專案檔存在性推斷。
# 專案自帶 wrapper 就用它 —— 理由與判定同 repo-index.ps1 的 wrapper 段（「腳本＋設定檔」都在才算），
# 兩邊由 test-repo-index.ps1 用同一組 fixture 釘住。
function Test-Wrapper([string[]]$scripts, [string]$props) {
    (@($scripts | Where-Object { Test-Path -LiteralPath $_ -PathType Leaf }).Count -gt 0) -and (Test-Path -LiteralPath $props -PathType Leaf)
}
if (-not $buildCmd) {
    if (Get-ChildItem -Recurse -Depth 3 -Filter *.sln -ErrorAction SilentlyContinue | Select-Object -First 1) {
        $buildCmd = 'dotnet build --nologo --verbosity quiet'
    } elseif (Get-ChildItem -Recurse -Depth 3 -Filter pom.xml -ErrorAction SilentlyContinue | Select-Object -First 1) {
        $mvn = if (Test-Wrapper @('mvnw', 'mvnw.cmd') '.mvn/wrapper/maven-wrapper.properties') { './mvnw' } else { 'mvn' }
        $buildCmd = "$mvn -q -B compile"
    } elseif (Get-ChildItem -Recurse -Depth 3 -Filter build.gradle* -ErrorAction SilentlyContinue | Select-Object -First 1) {
        $gradle = if (Test-Wrapper @('gradlew', 'gradlew.bat') 'gradle/wrapper/gradle-wrapper.properties') { './gradlew' } else { 'gradle' }
        $buildCmd = "$gradle -q compileJava"
    } else {
        exit $(if ($nodeFailed) { 2 } else { 0 })   # 無可辨識的專案，不阻斷
    }
}

$parts = $buildCmd -split '\s+'
$exe   = $parts[0]
if (-not (Get-Command $exe -ErrorAction SilentlyContinue)) { exit $(if ($nodeFailed) { 2 } else { 0 }) }   # 工具鏈不可用時不阻斷

$result = & $exe @($parts[1..($parts.Count - 1)]) 2>&1
if ($LASTEXITCODE -ne 0) {
    # 紅燈：清掉時間戳，讓下一次變更立即重驗，不受去抖視窗影響。
    Remove-Item $stamp -ErrorAction SilentlyContinue
    [Console]::Error.WriteLine("[Hook] Build FAILED after production code change ($buildCmd). Fix before proceeding.")
    $result | Select-Object -Last 10 | ForEach-Object { [Console]::Error.WriteLine($_) }
    exit 2
}
# 綠燈：記錄時間戳，開啟去抖視窗。
if ($DebounceSeconds -gt 0) { Set-Content -Path $stamp -Value (Get-Date -Format o) -NoNewline }
exit $(if ($nodeFailed) { 2 } else { 0 })
